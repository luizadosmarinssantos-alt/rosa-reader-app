package PACKAGE_NAME;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Locale;

@CapacitorPlugin(name = "LocalBookScanner")
public class LocalBookScanner extends Plugin {
    @PluginMethod
    public void requestAllFilesAccess(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()) {
            JSObject out = new JSObject(); out.put("granted", true); call.resolve(out); return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getContext().getPackageName()));
            startActivityForResult(call, intent, result -> {
                JSObject out = new JSObject();
                boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager();
                out.put("granted", granted); call.resolve(out);
            });
        } catch (Exception e) { call.reject("Não consegui abrir as configurações de acesso aos arquivos: " + e.getMessage()); }
    }

    @PluginMethod
    public void hasAllFilesAccess(PluginCall call) {
        JSObject out = new JSObject();
        out.put("granted", Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager());
        call.resolve(out);
    }

    @PluginMethod
    public void listBooks(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            call.reject("Permita o acesso a todos os arquivos nas configurações do Android."); return;
        }
        JSONArray files = new JSONArray();
        File root = Environment.getExternalStorageDirectory();
        scan(root, files, 0);
        JSObject out = new JSObject(); out.put("files", files); out.put("root", root.getAbsolutePath()); call.resolve(out);
    }

    private void scan(File dir, JSONArray out, int depth) {
        if (dir == null || depth > 12 || !dir.isDirectory() || !dir.canRead()) return;
        String p = dir.getAbsolutePath();
        if (p.contains("/Android/data") || p.contains("/Android/obb") || p.contains("/.")) return;
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File f : children) {
            try {
                if (f.isDirectory()) scan(f, out, depth + 1);
                else if (f.isFile()) {
                    String n = f.getName().toLowerCase(Locale.ROOT);
                    if (n.endsWith(".pdf") || n.endsWith(".epub")) {
                        JSONObject item = new JSONObject(); item.put("id", f.getAbsolutePath());
                        item.put("name", f.getName()); item.put("path", f.getAbsolutePath()); item.put("size", f.length());
                        out.put(item);
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    @PluginMethod
    public void readBook(PluginCall call) {
        String path = call.getString("id");
        if (path == null || !path.startsWith(Environment.getExternalStorageDirectory().getAbsolutePath())) {
            call.reject("Caminho do arquivo inválido."); return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            call.reject("Permissão de arquivos não concedida."); return;
        }
        File f = new File(path);
        if (!f.isFile() || f.length() > 80L * 1024 * 1024) { call.reject("Arquivo inexistente ou maior que 80 MB nesta versão."); return; }
        try (InputStream in = new FileInputStream(f); ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] bytes = new byte[32768]; int n;
            while ((n = in.read(bytes)) > 0) buffer.write(bytes, 0, n);
            JSObject out = new JSObject(); out.put("name", f.getName());
            out.put("base64", Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP)); call.resolve(out);
        } catch (Exception e) { call.reject("Não consegui ler o arquivo: " + e.getMessage()); }
    }
}
