# Rosa Reader — projeto Android

Este projeto é uma base Android (Capacitor) para o Rosa Reader. O repositório inclui a interface existente em `web/index.html`, um fluxo de compilação pelo GitHub Actions e PDF.js empacotado no build para não depender de CDN durante a leitura de PDF.

## Recursos presentes na interface
- Importação manual de vários arquivos EPUB/PDF pelo seletor de arquivos.
- Biblioteca e metadados persistidos em IndexedDB no aparelho.
- Progresso, marcações e notas persistidos localmente.
- Categorias Favoritos, Ler mais tarde, Lidos e Excluídos.
- EPUB convertido em blocos de texto para leitura; PDF processado a partir do texto selecionável.
- Tela dividida vertical para mostrar dois livros já importados.

## Limitações conhecidas
- Ainda não há suporte para leitura de MOBI.
- PDF digitalizado sem camada de texto não abre nesta versão; OCR não está incluído.
- A importação local é feita por escolha explícita de arquivos/pastas; o Android não permite varrer o armazenamento inteiro sem autorização.
- A tela dividida e a persistência precisam ser testadas em aparelhos Android reais. O fluxo de build produz um APK de debug, não um app publicado.
- PDF.js fica empacotado localmente após `npm run build`; a primeira compilação precisa de internet para instalar as dependências.

## Compilar na nuvem
O workflow `.github/workflows/build-apk.yml` roda ao enviar alterações para `main`/`master` ou manualmente em Actions. Ao concluir, o artefato `rosa-reader-debug-apk` contém `app-debug.apk`.

## Desenvolvimento local
```bash
npm install
npm test
npm run build
npx cap add android
npx cap sync android
```
Depois, compile o Android com Gradle em um ambiente que tenha Java/Android SDK.


## Busca de PDFs e EPUBs no Android

Na versão Android compilada pelo workflow, a área de biblioteca inclui **Encontrar PDFs e EPUBs no celular**. Na versão Android, o botão pede a permissão especial de acesso a todos os arquivos nas Configurações do sistema. Depois da autorização, o app procura arquivos PDF e EPUB no armazenamento compartilhado acessível, inclusive em Downloads e subpastas, e permite importar vários de uma vez. O Android continua protegendo áreas privadas de outros aplicativos. Essa permissão especial pode não ser aceita para distribuição pela Google Play; para instalar por APK de teste, o Android permite que o usuário a autorize quando disponível.

Limites desta implementação: ela não varre áreas privadas de outros aplicativos nem todo o armazenamento sem autorização; a pasta deve ser escolhida pelo usuário. A importação por essa ponte tem limite de 80 MB por arquivo nesta versão. A compilação e os testes de código não substituem o teste em um aparelho Android real.
