const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const src = path.join(root, 'node_modules', 'pdfjs-dist', 'build');
const dst = path.join(root, 'web', 'vendor');
fs.mkdirSync(dst, { recursive: true });
for (const file of ['pdf.min.js', 'pdf.worker.min.js']) {
  const from = path.join(src, file);
  if (!fs.existsSync(from)) throw new Error(`Dependência PDF.js ausente: ${from}`);
  fs.copyFileSync(from, path.join(dst, file));
}
const htmlPath = path.join(root, 'web', 'index.html');
let html = fs.readFileSync(htmlPath, 'utf8');
if (!html.includes('./vendor/pdf.min.js')) throw new Error('A interface não está apontando para PDF.js local.');
if (!html.includes('Rosa Reader')) throw new Error('Não foi possível validar a interface principal.');
console.log('Build web concluído: PDF.js e worker copiados para web/vendor.');

// Instala a ponte nativa Android para selecionar uma pasta e localizar PDFs/EPUBs.
const androidDir = path.join(root, 'android');
if (fs.existsSync(androidDir)) {
  const javaRoot = path.join(androidDir, 'app', 'src', 'main', 'java');
  function findMainActivity(dir) {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) { const hit = findMainActivity(full); if (hit) return hit; }
      else if (ent.name === 'MainActivity.java' || ent.name === 'MainActivity.kt') return full;
    }
    return null;
  }
  const activity = findMainActivity(javaRoot);
  if (!activity) throw new Error('MainActivity do Android não encontrada.');
  const manifestPath = path.join(androidDir, 'app', 'src', 'main', 'AndroidManifest.xml');
  if (fs.existsSync(manifestPath)) {
    let manifest = fs.readFileSync(manifestPath, 'utf8');
    const permission = '<uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />';
    if (!manifest.includes('android.permission.MANAGE_EXTERNAL_STORAGE')) {
      manifest = manifest.replace('<application', permission + '\n    <application');
      fs.writeFileSync(manifestPath, manifest);
    }
  }
  const source = fs.readFileSync(activity, 'utf8');
  const pkg = (source.match(/package\s+([\w.]+)\s*;/) || [])[1];
  if (!pkg) throw new Error('Não foi possível identificar o pacote Android.');
  const pluginDir = path.join(javaRoot, ...pkg.split('.'));
  fs.mkdirSync(pluginDir, { recursive: true });
  const plugin = fs.readFileSync(path.join(root, 'android-native', 'LocalBookScanner.java'), 'utf8').replace('package PACKAGE_NAME;', 'package ' + pkg + ';');
  fs.writeFileSync(path.join(pluginDir, 'LocalBookScanner.java'), plugin);
  let updated = source;
  if (!updated.includes('LocalBookScanner')) {
    if (activity.endsWith('.java')) {
      updated = updated.replace(/(public class MainActivity extends BridgeActivity\s*\{)/, '$1\n    @Override\n    public void onCreate(android.os.Bundle savedInstanceState) {\n        registerPlugin(LocalBookScanner.class);\n        super.onCreate(savedInstanceState);\n    }');
    } else {
      updated = updated.replace(/(class MainActivity\s*:\s*BridgeActivity\(\)\s*\{)/, '$1\n    override fun onCreate(savedInstanceState: android.os.Bundle?) {\n        registerPlugin(LocalBookScanner::class.java)\n        super.onCreate(savedInstanceState)\n    }');
    }
    fs.writeFileSync(activity, updated);
  }
  console.log('Ponte Android de busca local instalada.');
}
