const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
test('a interface principal existe dentro de web/', () => {
  const p = path.join(root, 'web', 'index.html');
  assert.ok(fs.existsSync(p));
  const html = fs.readFileSync(p, 'utf8');
  assert.match(html, /id="imp"/);
  assert.match(html, /indexedDB\.open\("rosa"/);
});
test('PDF.js aponta para recursos locais, sem CDN', () => {
  const html = fs.readFileSync(path.join(root, 'web', 'index.html'), 'utf8');
  assert.match(html, /\.\/vendor\/pdf\.min\.js/);
  assert.match(html, /\.\/vendor\/pdf\.worker\.min\.js/);
  assert.doesNotMatch(html, /cdnjs\.cloudflare\.com\/ajax\/libs\/pdf\.js/);
});
test('configuração Capacitor aponta para web/', () => {
  const cfg = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
  assert.equal(cfg.webDir, 'web');
});
test('workflow de compilação está presente', () => {
  assert.ok(fs.existsSync(path.join(root, '.github', 'workflows', 'build-apk.yml')));
});

test('busca Android solicita acesso amplo e filtra PDF/EPUB recursivamente', () => {
  const plugin = fs.readFileSync(path.join(root, 'android-native', 'LocalBookScanner.java'), 'utf8');
  const html = fs.readFileSync(path.join(root, 'web', 'index.html'), 'utf8');
  const build = fs.readFileSync(path.join(root, 'scripts', 'build.js'), 'utf8');
  assert.match(plugin, /ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION/);
  assert.match(plugin, /Environment\.isExternalStorageManager\(\)/);
  assert.match(plugin, /n\.endsWith\("\.pdf"\) \|\| n\.endsWith\("\.epub"\)/);
  assert.match(build, /android\.permission\.MANAGE_EXTERNAL_STORAGE/);
  assert.match(html, /Encontrar PDFs e EPUBs no celular/);
  assert.match(html, /requestAllFilesAccess/);
});

test('a lupa de busca filtra a biblioteca por título ou autor', () => {
  const html = fs.readFileSync(path.join(root, 'web', 'index.html'), 'utf8');
  assert.match(html, /id="toggleSearch"/);
  assert.match(html, /id="bookSearch"/);
  assert.match(html, /toLocaleLowerCase\("pt-BR"\)/);
  assert.match(html, /applyBookSearch/);
});

test('a biblioteca tenta atualizar a busca nativa ao voltar ao app', () => {
  const html = fs.readFileSync(path.join(root, 'web', 'index.html'), 'utf8');
  assert.match(html, /visibilitychange/);
  assert.match(html, /refreshNativeIfNeeded/);
  assert.match(html, /hasAllFilesAccess/);
});
